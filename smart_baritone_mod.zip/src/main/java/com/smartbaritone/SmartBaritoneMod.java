
package com.smartbaritone;

import net.fabricmc.api.ModInitializer;

public class SmartBaritoneMod implements ModInitializer {
    @Override
    public void onInitialize() {
        System.out.println("Smart Baritone carregado!");
    }
}
